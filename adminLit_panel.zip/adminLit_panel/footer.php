<footer class="main-footer">
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">Ashvin Patidar</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.0.5
    </div>
</footer>
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div><!-- header wrapper -->

<script src="lite/js/jquery-ui.min.js"></script>
<script src="lite/js/bootstrap.bundle.min.js"></script>
<script src="lite/js/adminlte.js"></script>
<script src="lite/js/demo.js"></script>
</body>
</html>

<script type="text/javascript">
    $(document).ready(function(){
        //alert('hy');
    });
</script>